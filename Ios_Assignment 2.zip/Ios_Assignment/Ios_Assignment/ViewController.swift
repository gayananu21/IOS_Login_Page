//
//  ViewController.swift
//  Ios_Assignment
//
//  Created by Gayan Disanayaka on 1/23/21.
//  Copyright © 2021 Gayan Disanayaka. All rights reserved.
//

import UIKit

@IBDesignable class ViewController: UIViewController {

   
    @IBOutlet weak var apple_View: RoundButton!
    @IBOutlet weak var face_View: RoundButton!
    
    @IBOutlet weak var Google_View: RoundButton!
    
    @IBOutlet weak var Email_View: RoundButton!
    
    @IBOutlet weak var Main_View: UIView!
    @IBOutlet weak var plx: UILabel!
    @IBOutlet weak var why_Sign_Label: UILabel!
    @IBOutlet weak var line_View: UIView!
    
    @IBOutlet weak var terms_y_Label: UILabel!
    @IBOutlet weak var terms_Label: UILabel!
    @IBOutlet weak var x_Label: UILabel!
    override func viewDidLoad() {
        
        super.viewDidLoad()
                // Do any additional setup after loading the view.
                
                     
                      self.plx.layer.shadowColor = UIColor.lightGray.cgColor
                      self.plx.layer.shadowRadius = 3.0
                      self.plx.layer.shadowOpacity = 0.7
                      self.plx.layer.shadowOffset = CGSize(width: 4, height: 4)
                      self.plx.layer.masksToBounds = false
                           
                      self.x_Label.layer.shadowColor = UIColor.lightGray.cgColor
                      self.x_Label.layer.shadowRadius = 3.0
                      self.x_Label.layer.shadowOpacity = 0.7
                      self.x_Label.layer.shadowOffset = CGSize(width: 4, height: 4)
                                   self.x_Label.layer.masksToBounds = false
                      
                           
                    
                      
                      UIView.animate(withDuration: 0.0, delay: 0.0, options: .curveEaseOut, animations: {
                             self.plx.alpha = 0
                         }, completion: nil)
                               
                       UIView.animate(withDuration: 2, delay: 0.5, options: .curveEaseIn, animations: {
                                   self.plx.alpha = 1
                               }, completion: nil)
                               
                                     UIView.animate(withDuration: 0.0, delay: 0.0, options: .curveEaseOut, animations: {
                                   self.x_Label.alpha = 0
                               }, completion: nil)
                                     
                       UIView.animate(withDuration: 2, delay: 0.5, options: .curveEaseIn, animations: {
                                         self.x_Label.alpha = 1
                                       self.x_Label.textColor = UIColor .orange

                                     }, completion: nil)
                      
                       
                      
                       
                               
                               UIView.animate(withDuration: 0.0, delay: 0.0, options: .curveEaseOut, animations: {
                                        self.terms_Label.alpha = 0
                                    }, completion: nil)
                                          
                                          UIView.animate(withDuration: 1, delay: 1, options: .curveEaseIn, animations: {
                                              self.terms_Label.alpha = 1
                                          }, completion: nil)
                               
                               UIView.animate(withDuration: 0.0, delay: 0.0, options: .curveEaseOut, animations: {
                                   self.terms_y_Label.alpha = 0
                               }, completion: nil)
                                     
                                     UIView.animate(withDuration: 1, delay: 1, options: .curveEaseIn, animations: {
                                         self.terms_y_Label.alpha = 1
                                     }, completion: nil)
                               
                               UIView.animate(withDuration: 0.0, delay: 0.0, options: .curveEaseOut, animations: {
                                   self.why_Sign_Label.alpha = 0
                               }, completion: nil)
                                     
                                     UIView.animate(withDuration: 1, delay: 1, options: .curveEaseIn, animations: {
                                         self.why_Sign_Label.alpha = 1
                                     }, completion: nil)

                               UIView.animate(withDuration: 0.0, delay: 0.0, options: .curveEaseOut, animations: {
                                   self.line_View.alpha = 0
                               }, completion: nil)
                                     
                                     UIView.animate(withDuration: 0.5, delay: 1, options: .curveEaseIn, animations: {
                                         self.line_View.alpha = 1
                                     }, completion: nil)
                              

                          }
                          
                          override func viewDidAppear(_ animated: Bool) {
                              super.viewDidAppear(animated)
                             

                             self.apple_View.center.x = self.face_View.center.x // Place it in the center x of the view.
                             self.apple_View.center.x -= self.face_View.bounds.width // Place it on the left of the view with the width = the bounds'width of the view.
                             // animate it from the left to the right
                             UIView.animate(withDuration: 0.5, delay: 0, options: [.transitionFlipFromBottom], animations: {
                                 self.apple_View.center.x += self.face_View.bounds.width
                                   self.view.layoutIfNeeded()
                             }, completion: nil)
                             
                             
                             self.face_View.center.x = self.Google_View.center.x // Place it in the center x of the view.
                             self.face_View.center.x -= self.Google_View.bounds.width // Place it on the left of the view with the width = the bounds'width of the view.
                             // animate it from the left to the right
                             UIView.animate(withDuration: 1, delay: 0, options: [.transitionFlipFromBottom], animations: {
                                 self.face_View.center.x += self.Google_View.bounds.width
                                   self.view.layoutIfNeeded()
                             }, completion: nil)
                             
                             self.Google_View.center.x = self.Email_View.center.x // Place it in the center x of the view.
                             self.Google_View.center.x -= self.Email_View.bounds.width // Place it on the left of the view with the width = the bounds'width of the view.
                             // animate it from the left to the right
                             UIView.animate(withDuration: 1.5, delay: 0, options: [.transitionFlipFromBottom], animations: {
                                 self.Google_View.center.x += self.Email_View.bounds.width
                                   self.view.layoutIfNeeded()
                             }, completion: nil)
                             
                             self.Email_View.center.x = self.Google_View.center.x // Place it in the center x of the view.
                             self.Email_View.center.x -= self.Google_View.bounds.width // Place it on the left of the view with the width = the bounds'width of the view.
                             // animate it from the left to the right
                             UIView.animate(withDuration: 2, delay: 0, options: [.transitionFlipFromBottom], animations: {
                                 self.Email_View.center.x += self.Google_View.bounds.width
                                   self.view.layoutIfNeeded()
                             }, completion: nil)
                             
                                 
                                    
                              
                              
                          }
                
                  
                          
                          
                          
                          
                      }

